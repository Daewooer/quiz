print("Hello, What is up?")
user_input = input()

if user_input == "bad":
  print("Everything would be fine, don't worry")

else:
  print("That is good")
#first question done!

print("Are you ready for a a quiz?")
user_input1 = input()

if user_input1 == "no":
  print("Get the hell out of here")

else:
  print("Good let's start")
#start of the quiz is done!

print("1st question: Who is the most beautifull person you know?")
user_input2 = input()
  
if user_input == "me":
  print("CORRECT!!!!!!!!")

else:
  print("Wrong, is you!")
